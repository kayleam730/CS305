package com.snhu.sslserver;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

@RestController
public class ChecksumController {

    @GetMapping("/hash")
    public String getChecksum() {
        try {
            String data = "Hello World Check Sum!";
            // Generate SHA-256 checksum
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = digest.digest(data.getBytes());

            // Encode to Base64 for display
            String checksum = Base64.getEncoder().encodeToString(hashBytes);

            return "Developer: Kaylea Carpenter<br>" +
            "Original String: " + data + "<br>" +
            "SHA-256 Checksum (Base64): " + checksum;
        } catch (NoSuchAlgorithmException e) {
            return "Error generating checksum: " + e.getMessage();
        }
    }
}
